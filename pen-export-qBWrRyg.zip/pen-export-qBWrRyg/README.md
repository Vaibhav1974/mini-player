# Mini Music Player - VueJS

A Pen created on CodePen.io. Original URL: [https://codepen.io/JavaScriptJunkie/pen/qBWrRyg](https://codepen.io/JavaScriptJunkie/pen/qBWrRyg).

Mini Music Player built with VueJs. design by Voicu Apostol on dribbble. 

design: https://dribbble.com/shots/3533847-Mini-Music-Player